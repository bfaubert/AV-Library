tinyMCE.addI18n('en.code', {
	desc : 'Insert Code'
});
